/* Stub declarations to make some examples in Ref2 work */

void continue_running_parent(struct event_base *);
void continue_running_child(struct event_base *);
